function scrollToPortfolio() {
  document.getElementById('portfolio').scrollIntoView({ behavior: 'smooth' });
}
function abrirModal() {
  document.getElementById('modalContato').style.display = 'flex';
}
function fecharModal() {
  document.getElementById('modalContato').style.display = 'none';
}
window.onclick = function(event) {
  const modal = document.getElementById('modalContato');
  if (event.target == modal) {
    fecharModal();
  }
};
document.getElementById('formContato').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Mensagem enviada! Obrigado por entrar em contato.');
  fecharModal();
});